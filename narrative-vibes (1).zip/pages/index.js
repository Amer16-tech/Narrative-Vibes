export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-gray-100 to-gray-200">
      <h1 className="text-5xl font-bold text-gray-900 mb-4">Narrative Vibes</h1>
      <p className="text-lg text-gray-700 max-w-xl text-center">
        A platform for literary articles, book reviews, creative writing, original stories, and poetry.
      </p>
      <p className="mt-6 text-sm text-gray-500">Coming Soon...</p>
    </main>
  )
}
